#include "Uart.h"

uint8_t rxd_index = 0;
uint8_t rxd_buf[30];
uint8_t rxd_flag = 0;

void Uart1_Configuration(void)
{
    GPIO_InitTypeDef GPIO_InitStructure; 
    USART_InitTypeDef USART_InitStructure; 
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE); 

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; //TX
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10; //RX
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; 
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    USART_InitStructure.USART_BaudRate = 9600; 
    USART_InitStructure.USART_WordLength = USART_WordLength_8b; 
    USART_InitStructure.USART_StopBits = USART_StopBits_1; 
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;  
    USART_Init(USART1, &USART_InitStructure); 

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE); //接收中断

    USART_Cmd(USART1, ENABLE);
}

void Uart1_NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure; 
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1); 
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn; 
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; 
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
    NVIC_Init(&NVIC_InitStructure); 

}

int fputc(int c, FILE *pt)
{
    USART_TypeDef* USARTx = USART1;
    while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);
    USART_SendData(USARTx, c);
    while(USART_GetFlagStatus(USARTx, USART_FLAG_TC) == RESET);
    
    return 0;
}

int fgetc(FILE *pt)
{
    USART_TypeDef* USARTx = USART1;
    while(USART_GetFlagStatus(USARTx, USART_FLAG_RXNE) == RESET);
    return (int)USART_ReceiveData(USARTx);
}

void Rec_Data(void)
{
		if(rxd_flag == 1)
		{
            printf("$");
			printf("%s",rxd_buf);
            printf("#");
            printf("\n");
            rxd_flag = 0;
		}
}

void APP_Control(void)
{
    if(rxd_flag == 1)
    {
        switch(rxd_buf[0])
        {
            case '1':
                Rec_Data();
            printf("APP Function:Forward!\n");
                break;
            case '2':
                Rec_Data();
                printf("APP Function:Backward!\n");
                break;
            case '3':
                Rec_Data();
                printf("APP Function:Left!\n");
                break;
            case '4':
                Rec_Data();
                printf("APP Function:Right!\n");
                break;
        }
        switch(rxd_buf[2])
        {
            case '1':
                Rec_Data();
                printf("APP Function:SpinLeft!\n");
                break;
            case '2':
                Rec_Data();
                printf("APP Function:SpinRight!\n");
                break;
        }
        switch(rxd_buf[4])
        {
            case '1':
                Rec_Data();
                printf("APP Function:Whistle!\n");
                break;
        }
        switch(rxd_buf[6])
        {
            case '1':
                Rec_Data();
                printf("APP Function:SpeedUp!\n");
                break;
            case '2':
                Rec_Data();
                printf("APP Function:SpeedDown!\n");
                break;
        }
        if((rxd_buf[0] == '0') && (rxd_buf[2] == '0') && (rxd_buf[4] == '0') && (rxd_buf[6] == '0') && (rxd_buf[8] == '0') && (rxd_buf[10] == '0') && (rxd_buf[12] == '0') && (rxd_buf[14] == '0') && (rxd_buf[16] == '0'))
        {
            Rec_Data();
            printf("APP Function:Stop!\n");
        }
        rxd_flag = 0;
    }
    
}


void USART1_IRQHandler(void)
{
    uint8_t recv_dat = 0;
    static uint8_t rec_state = 0;
    while(USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == SET)
    {
        recv_dat = USART_ReceiveData(USART1);
        
        switch(rec_state)
        {
        case 0:
            if((recv_dat == '$') && (!rxd_flag))
            {
                rec_state = 1;
                rxd_index = 0;
            }
            else 
            {
                rec_state = 0;
            }
            break;
        case 1:
            if(recv_dat == '#')
            {
                rxd_flag = 1;
                rec_state = 0;
            }
            else
            {
                rxd_buf[rxd_index++] = recv_dat;
            }
            break;
        }
    }		
}

