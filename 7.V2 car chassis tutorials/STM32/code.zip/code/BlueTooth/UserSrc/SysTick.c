#include "SysTick.h"

static uint8_t fac_us = 0;
static uint16_t fac_ms = 0;

void delay_init(void)
{
	uint8_t SYSCLK = SystemCoreClock / 1000000;
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8); // 选择外部时钟  HCLK/8
	fac_us = SYSCLK / 8;
	fac_ms = (uint16_t)fac_us * 1000;
}

void delay_us(uint32_t nus)
{
	uint32_t temp;
	SysTick->LOAD = nus * fac_us; //时间加载
	SysTick->VAL = 0x00;		  //清空计数器
	SysTick->CTRL = 0x01;		  //开始倒数
	do
	{
		temp = SysTick->CTRL;
	} while (temp & 0x01 && !(temp & (1 << 16))); //等待时间到达
	SysTick->CTRL = 0x00;						  //关闭计数器
	SysTick->VAL = 0X00;						  //清空计数器
}

void delay_ms(uint16_t nms)
{
	uint32_t temp;
	SysTick->LOAD = (uint32_t)nms * fac_ms; //时间加载(SysTick->LOAD为24bit)
	SysTick->VAL = 0x00;			   //清空计数器
	SysTick->CTRL = 0x01;			   //开始倒数
	do
	{
		temp = SysTick->CTRL;
	} while (temp & 0x01 && !(temp & (1 << 16))); //等待时间到达
	SysTick->CTRL = 0x00;						  //关闭计数器
	SysTick->VAL = 0X00;						  //清空计数器
}


